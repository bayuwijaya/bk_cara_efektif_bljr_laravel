<?
class user extends Eloquent {}