<?php 
class Book extends Eloquent 
{ 

}  
?>