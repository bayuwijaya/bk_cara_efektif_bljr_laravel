<?
class Abc 
{
	public function all()
	{
		return "Showing all shows :/";
	}
}