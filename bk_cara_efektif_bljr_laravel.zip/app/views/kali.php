<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Laravel PHP Framework</title>
	<style>
	</style>
</head>
<body>
<form action="kali" method="post">
  <b>Masukan Data Berikut !!!</b><br>
  <input type="text" name="data2"> * 
  <input type="text" name="data1">
  <br><input type="submit" value="Hitung!!!">
</form>

</body>
</html>
