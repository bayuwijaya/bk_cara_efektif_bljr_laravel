<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='utf-8' />
<title>CONTOH APLIKASI</title>

<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1' />
 {{ HTML::style('css/bootstrap.min.css') }}

</head>
<body>

@yield('content')

{{ HTML::script('js/jquery.min.js') }}
{{ HTML::script('js/bootstrap.js') }}

</body>
</html>