<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Laravel PHP Framework</title>
	<style>
	</style>
</head>
<body>
<form action="login" method="post">
  Username:
  <input type="text" name="username"><br>
  Password:
  <input type="password" name="password">
  <input type="submit" value="Login">
</form>

</body>
</html>
