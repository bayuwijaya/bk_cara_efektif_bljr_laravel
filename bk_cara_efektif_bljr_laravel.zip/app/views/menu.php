<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Menu Perhitungan</title>
	<style>
	</style>
</head>
<body
<b>Halaman Menu Hitung Simple</b>
<ul>
    <li><a href="./">Home</a></li>
    <li><a href="./tambah">Penjumlahan</a></li>
    <li><a href="./kali">Perkalian</a></li>
  </ul>
</body>
</html>
