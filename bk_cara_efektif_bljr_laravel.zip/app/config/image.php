<?php
return array(
	'upload_folder' => 'uploads',
	'thumb_folder' => 'uploads/thumbs',
	'thumb_width' => 320,
	'thumb_height' => 240
);