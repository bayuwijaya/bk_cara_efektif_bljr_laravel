<?
class FileController extends \BaseController 
{
	public function inputFile() 
	{ 
		return View::make('fileform');
	}
}
	