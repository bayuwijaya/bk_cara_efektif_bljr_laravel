<?php

class BuatController extends \BaseController 
{

	public function register()
	{
		return View::make('tampil');
	}
	public function prosesInput()
	{
		//
	}
}
